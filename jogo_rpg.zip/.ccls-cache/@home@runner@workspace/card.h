#ifndef CARD_H
#define CARD_H

#include <string>


class Card{
  public:
    Card(int value, std::string suit);

    void toString();

  private:
    int value_ = 0;
    std::string suit_ = "";
};

#endif