#include <cmath>
#include <iostream>
#include <string>

class Circle {
public:
Circle(double radius) : radius_(radius) {}

double getRadios() const {
  return radius_;
}

double getArea() const{
  double area = M_PI * radius_ * radius_;
  return area;
}

private:
double radius_ = 0.0;
};

int main() {

  Circle circle1(1.0);

  std::cout << "Radius: " << circle1.getRadios() << std::endl;

  double area1 = circle1.getArea();
  std::cout << "Area: " << area1 << std::endl;


}