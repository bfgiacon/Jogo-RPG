#include "card.h"
#include <iostream>
#include <string>


Card::Card(int value, std::string suit) : value_(value), suit_(suit) {}

void Card::toString(){
  std::cout << std::to_string(value_) << " of " << suit_ << std::endl; 
}