#include "arquer.h"
#include <iostream>

void Arquer::attack() const{
  std::cout << "Ataque com arco e flecha" << std::endl;
}