#ifndef BASE_H
#define BASE_H

#include <string>
#include <iostream>


class Base{
public:
  Base(){
  std::cout << "Base constructor" << std::endl;
}

  virtual ~Base(){
  std::cout << "Base destructor" << std::endl;
}

};

#endif 