#include <string>
#include <iostream>
#include <ostream>
#include <cctype>

//função para ver se é o inicio de uma palavra
std::string analizarFrase(std::string& frase){   //usando referencia para não criar cópias
  for(int i = 0; i < frase.size(); i++){         //vai rodar do zero até .size - 1
    if(i == 0 || frase[i - 1] == ' '){           //se for a primeira letra ou se for um espaço
      frase[i] = std::toupper(frase[i]);         //a letra vai ser maiuscula
  }
}  
  return frase;                                  //retorna frase inteira 
}


//main
int main(){

  std::string fraseTest1 = "aqui tem um teste";
  analizarFrase(fraseTest1);
  std::cout << fraseTest1 << std::endl;

  return 0;
}